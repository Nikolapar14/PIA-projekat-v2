import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GostdostaveComponent } from './gostdostave.component';

describe('GostdostaveComponent', () => {
  let component: GostdostaveComponent;
  let fixture: ComponentFixture<GostdostaveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GostdostaveComponent]
    });
    fixture = TestBed.createComponent(GostdostaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
