import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Dostava } from '../models/dostava';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class DostavaService {

  constructor(private http: HttpClient) { }

  dohvatiDostave(){

    return this.http.get<Dostava[]>("http://localhost:4000/dostava/dohvatiDostave")

   }

   dodajDostavu(dostava: Dostava){

    const data = {
      dostava: dostava
    }

    return this.http.post<Message>("http://localhost:4000/dostava/dodajDostavu",data)

   }

   azuriraj(dostava: Dostava){

    const data = {
      dostava: dostava
    }

    return this.http.post<Message>("http://localhost:4000/dostava/azuriraj",data)

   }

}
