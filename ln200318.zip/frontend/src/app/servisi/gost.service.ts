import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Gost } from '../models/gost';
import { Message } from '../models/message';
import { Admin } from '../models/admin';

@Injectable({
  providedIn: 'root'
})
export class GostService {

  constructor(private http: HttpClient) { }

  nadjiGostaUsername(username: String){
    const data = {
      username: username
    }

    return this.http.post<Gost>("http://localhost:4000/gost/nadjiGostaUsername",data)

  }

  nadjiGostaEmail(email: string) {

    const data = {
      email : email
    }

    return this.http.post<Gost>("http://localhost:4000/gost/nadjiGostaEmail",data)
  }

  registracijaGost(gost: Gost){

    const data = {
        korisnickoIme: gost.korisnickoIme,
        lozinka: gost.lozinka,
        bezbedonosnoPitanje: gost.bezbedonosnoPitanje,
        odgovor: gost.odgovor,
        ime: gost.ime,
        prezime: gost.prezime,
        pol: gost.pol,
        adresa: gost.adresa,
        kontaktTelefon: gost.kontaktTelefon,
        email: gost.email,
        profilnaSlika: gost.profilnaSlika,
        brojKreditneKartice: gost.brojKreditneKartice,
        aktivan : 0
    }

    return this.http.post<Message>("http://localhost:4000/gost/register",data)
  }

  loginGost(username: String, password: String ){

    const data = {

      username: username,
      password: password

    }

    return this.http.post<Gost>("http://localhost:4000/gost/login",data)

  }

  loginAdmin(username: String, password: String ){

    const data = {

      username: username,
      password: password

    }

    return this.http.post<Admin>("http://localhost:4000/gost/loginAdmin",data)

  }

  promenaSifre(username: String, novaLozinka: String, staraLozinka: String ){

    const data = {

      username: username,
      staraLozinka : staraLozinka,
      novaLozinka : novaLozinka

    }

    return this.http.post<Message>("http://localhost:4000/gost/promenaLozinke", data)

  }

  azurirajGosta(gost: Gost){

    const data = {
      gost: gost
    }

    return this.http.post<Message>("http://localhost:4000/gost/azurirajGosta",data)

  }

  dohvatiGoste(){

    return this.http.get<Gost[]>("http://localhost:4000/gost/dohvatiGoste")
  }

  aktivirajGosta(username: String){

    const data = {
      korisnickoIme : username
    }

    return this.http.post<Message>("http://localhost:4000/gost/aktivirajGosta",data)

  }

  deaktivirajGosta(username: String){

    const data = {
      korisnickoIme : username
    }

    return this.http.post<Message>("http://localhost:4000/gost/deaktivirajGosta",data)

  }


}
