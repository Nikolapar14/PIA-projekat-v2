import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Rezervacija } from '../models/rezervacija';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class RezervacijaService {

  constructor(private http: HttpClient) {
   }


   dohvatiRezervacije(){

    return this.http.get<Rezervacija[]>("http://localhost:4000/rezervacija/dohvatiRezervacije")

   }

   dodajRezervaciju(rezervacija: Rezervacija){

    const data = {
      rezervacija : rezervacija
    }

    return this.http.post<Message>("http://localhost:4000/rezervacija/dodajRezervaciju", data)

   }

   azurirajRezervaciju(rezervacija: Rezervacija){

    const data = {
      rezervacija: rezervacija
    }

    return this.http.post<Message>("http://localhost:4000/rezervacija/azurirajRezervaciju", data)


   }


}
