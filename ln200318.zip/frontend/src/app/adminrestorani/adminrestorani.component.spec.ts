import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminrestoraniComponent } from './adminrestorani.component';

describe('AdminrestoraniComponent', () => {
  let component: AdminrestoraniComponent;
  let fixture: ComponentFixture<AdminrestoraniComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminrestoraniComponent]
    });
    fixture = TestBed.createComponent(AdminrestoraniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
