import { Component, OnInit } from '@angular/core';
import { GostService } from '../servisi/gost.service';
import { Gost } from '../models/gost';
import { Message } from '../models/message';


@Component({
  selector: 'app-registracija',
  templateUrl: './registracija.component.html',
  styleUrls: ['./registracija.component.css']
})
export class RegistracijaComponent implements OnInit {

  constructor(private gostServis: GostService){}

  selectedFile: string | null = null;
  selectedImage:string | null = null;

  greska1: boolean = false;
  greska2: boolean = false;
  greska3: boolean = false;
  greska4: boolean = false;

  formatLozinkaGreska: boolean = false

  gost: Gost = new Gost()

  ngOnInit(): void {



    this.gost.adresa = ""
    this.gost.bezbedonosnoPitanje= ""
    this.gost.brojKreditneKartice = ""
    this.gost.email = ""
    this.gost.ime = ""
    this.gost.kontaktTelefon = ""
    this.gost.korisnickoIme = ""
    this.gost.lozinka = ""
    this.gost.odgovor = ""
    this.gost.pol = ""
    this.gost.prezime = ""
    this.gost.profilnaSlika = null

  }

  onFileSelected(event: any): void {
    const fileInput = event.target;
    const file = (fileInput.files as FileList)[0];

    if (file) {
      // You can add additional logic here, such as validating the file type and size

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => {
        this.selectedImage = reader.result as string;
      };
    }
  }

  validatePassword(password: string) {
    const regex = /^(?=.*[A-Z])(?=.*[a-z]{3})(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z][A-Za-z\d!@#$%^&*()_+]{5,9}$/;
    return regex.test(password);
  }

  encryptMessage(message: string): string {
    let encryptedMessage = '';
    for (let i = 0; i < message.length; i++) {
        let char = message[i];

        if (/[a-zA-Z]/.test(char)) {

            let code = message.charCodeAt(i);
            if (char === char.toUpperCase()) {
                char = String.fromCharCode(((code - 65 + 3) % 26) + 65);
            } else {
                char = String.fromCharCode(((code - 97 + 3) % 26) + 97);
            }
        }
        encryptedMessage += char;
    }
    return encryptedMessage;
}

  submit(){

    this.gost.profilnaSlika = this.selectedImage

    if(this.gost.korisnickoIme == "" || this.gost.ime == "" || this.gost.prezime == ""|| this.gost.lozinka == "" || this.gost.odgovor == "" || this.gost.adresa == "" || this.gost.kontaktTelefon == "" || this.gost.email == ""){
      this.greska1 = true
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = false
    }else if( this.gost.bezbedonosnoPitanje == ""){

      this.greska1 = false
      this.greska2 = true
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = false

    }else if(this.gost.pol == ""){
      this.greska1 = false
      this.greska2 = false
      this.greska3 = true
      this.greska4 = false

      this.formatLozinkaGreska = false

    }else if(!this.validatePassword(this.gost.lozinka)){
      this.greska1 = false
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = true
    }else{

      this.greska1 = false
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false

      this.formatLozinkaGreska = false

      this.gostServis.nadjiGostaUsername(this.gost.korisnickoIme).subscribe(
        (data: Gost)=>{
          if(data)alert("Gost sa unetim korisničkim imenom već postoji u sistemu!");else{

            this.gostServis.nadjiGostaEmail(this.gost.email).subscribe(
              (data: Gost)=>{
                if(data)alert("Gost sa unetom email adresom već postoji!");
                else{

                  this.gost.lozinka = this.encryptMessage(this.gost.lozinka)

                  this.gostServis.registracijaGost(this.gost).subscribe(
                    (msg: Message)=>{
                      if(msg.message == 'ok'){
                        alert("Korisnik uspešno registrovan!")
                        window.location.href = ""

                      }else{
                        alert("Korisnik nije registrovan!")
                      }
                    }
                  )

                }
              }
            )

          }
        }
      )






    }



  }

}
