import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { Konobar } from '../models/konobar';
import { Restoran } from '../models/restoran';
import { Rezervacija } from '../models/rezervacija';
import { RestoranService } from '../servisi/restoran.service';
import { RezervacijaService } from '../servisi/rezervacija.service';

@Component({
  selector: 'app-statistika',
  templateUrl: './statistika.component.html',
  styleUrls: ['./statistika.component.css']
})
export class StatistikaComponent implements OnInit {

  constructor(private restoranServis: RestoranService, private rezervacijeServis: RezervacijaService) {}

  ulogovan: Konobar = new Konobar();
  restoran: Restoran = new Restoran();

  rezervacijeKonobara: Rezervacija[] = [];
  rezervacijeRestorana: Rezervacija[] = [];
  konobariGosti: { [key: string]: number } = {};

  ngOnInit(): void {
    let ul = localStorage.getItem("ulogovan");
    if (ul) this.ulogovan = JSON.parse(ul);

    this.restoranServis.dohvatiRestorane().subscribe((res: Restoran[]) => {
      if (res) {
        for (let i = 0; i < res.length; i++) {
          if (res[i].naziv == this.ulogovan.restoran) {
            this.restoran = res[i];
            break;
          }
        }
      }

      this.rezervacijeServis.dohvatiRezervacije().subscribe((rez: Rezervacija[]) => {
        if (rez) {
          rez.forEach(r => {
            if (r.zaduzenKonobar == this.ulogovan.korisnickoIme) {
              this.rezervacijeKonobara.push(r);
            }
            if (r.restoran == this.ulogovan.restoran) {
              this.rezervacijeRestorana.push(r);
              if (!this.konobariGosti[r.zaduzenKonobar]) {
                this.konobariGosti[r.zaduzenKonobar] = 0;
              }
              this.konobariGosti[r.zaduzenKonobar] += r.brojMesta;
            }
          });
          this.prikaziBarChart();
          this.prikaziHistogram();
          this.prikaziPieChart();
        }
      });
    });
  }

  prikaziBarChart(): void {
    const brojRezervacijaPoDanima = this.rezervacijeKonobara.reduce((acc: any, rez) => {
      const dan = new Date(rez.rezervacijaOd).toLocaleDateString();
      if (!acc[dan]) {
        acc[dan] = 0;
      }
      acc[dan] += rez.brojMesta;
      return acc;
    }, {});

    const labels = Object.keys(brojRezervacijaPoDanima);
    const data = Object.values(brojRezervacijaPoDanima);

    const ctx = document.getElementById('myBarChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Broj gostiju po danima',
          data: data,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }

  prikaziHistogram(): void {
    const brojRezervacijaPoDanima = this.rezervacijeRestorana.reduce((acc:any, rez) => {
      const danUNedelji = new Date(rez.rezervacijaOd).getDay();
      if (!acc[danUNedelji]) {
        acc[danUNedelji] = { count: 0, total: 0 };
      }
      acc[danUNedelji].count++;
      acc[danUNedelji].total += rez.brojMesta;
      return acc;
    }, {});

    const daniUNedelji = ['NED', 'PON', 'UTO', 'SRE', 'ČET', 'PET', 'SUB'];
    const labels = daniUNedelji;
    const data = labels.map((_, i) => {
      const dan = brojRezervacijaPoDanima[i] || { count: 0, total: 0 };
      return dan.count ? dan.total / dan.count : 0;
    });

    const ctx = document.getElementById('myHistogram') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Prosečan broj rezervacija po danima u sedmici',
          data: data,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }

  prikaziPieChart(): void {
    const labels = Object.keys(this.konobariGosti);
    const data = Object.values(this.konobariGosti);

    const ctx = document.getElementById('myPieChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          label: 'Raspodela gostiju među konobarima',
          data: data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(255, 159, 64, 0.2)'
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Raspodela gostiju među konobarima'
          }
        }
      }
    });
  }

}
