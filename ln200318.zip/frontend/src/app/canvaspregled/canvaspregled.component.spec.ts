import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CanvaspregledComponent } from './canvaspregled.component';

describe('CanvaspregledComponent', () => {
  let component: CanvaspregledComponent;
  let fixture: ComponentFixture<CanvaspregledComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CanvaspregledComponent]
    });
    fixture = TestBed.createComponent(CanvaspregledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
