import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GostrezervacijeComponent } from './gostrezervacije.component';

describe('GostrezervacijeComponent', () => {
  let component: GostrezervacijeComponent;
  let fixture: ComponentFixture<GostrezervacijeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GostrezervacijeComponent]
    });
    fixture = TestBed.createComponent(GostrezervacijeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
