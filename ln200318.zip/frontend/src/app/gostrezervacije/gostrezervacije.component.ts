import { Component, OnInit } from '@angular/core';
import { RezervacijaService } from '../servisi/rezervacija.service';
import { Rezervacija } from '../models/rezervacija';
import { Gost } from '../models/gost';

@Component({
  selector: 'app-gostrezervacije',
  templateUrl: './gostrezervacije.component.html',
  styleUrls: ['./gostrezervacije.component.css']
})
export class GostrezervacijeComponent implements OnInit{

  constructor(private rezervacijaServis : RezervacijaService){}

  ulogovan: Gost = new Gost()
  rezervacijeKorisnikaAktivne : Rezervacija[] = []
  rezervacijeKorisnikaGotove : Rezervacija[] = []

  ngOnInit(): void {

    let ul = localStorage.getItem("ulogovan")
    if(ul)this.ulogovan = JSON.parse(ul)

    this.rezervacijaServis.dohvatiRezervacije().subscribe((rez: Rezervacija[])=>{
      if(rez){

        rez.forEach(r=>{
          if(r.korisnickoIme == this.ulogovan.korisnickoIme){
            if(r.gotov == 0){
              this.rezervacijeKorisnikaAktivne.push(r)
            }else{
              this.rezervacijeKorisnikaGotove.push(r)
            }

          }
        })

        this.rezervacijeKorisnikaGotove.sort((a,b)=>{
          return b.rezervacijaOd.localeCompare(a.rezervacijaOd)
        })

      }
    })

  }

}
