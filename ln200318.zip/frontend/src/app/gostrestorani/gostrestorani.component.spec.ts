import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GostrestoraniComponent } from './gostrestorani.component';

describe('GostrestoraniComponent', () => {
  let component: GostrestoraniComponent;
  let fixture: ComponentFixture<GostrestoraniComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GostrestoraniComponent]
    });
    fixture = TestBed.createComponent(GostrestoraniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
