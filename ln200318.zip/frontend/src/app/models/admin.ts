export class Admin{
  korisnickoIme: string = ""
  lozinka : string = ""
}
