export class Jelo {

  jelo: string = ""
  cena: number = 0
  namirnice: string = ""
  slika: string = ""



}
