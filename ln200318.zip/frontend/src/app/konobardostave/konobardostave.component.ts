import { Component, OnInit } from '@angular/core';
import { Dostava } from '../models/dostava';
import { DostavaService } from '../servisi/dostava.service';
import { Konobar } from '../models/konobar';
import { Message } from '../models/message';

@Component({
  selector: 'app-konobardostave',
  templateUrl: './konobardostave.component.html',
  styleUrls: ['./konobardostave.component.css']
})
export class KonobardostaveComponent implements OnInit {

  constructor(private dostavaServis: DostavaService){}

  dostave: Dostava[] = []
  ulogovan: Konobar = new Konobar()

  procenjenoVreme: string[] = []

  checkedPrihvati: boolean[] = []
  checkedOdbij: boolean[] = []

  ngOnInit(): void {

    let ul = localStorage.getItem("ulogovan")
    if(ul)this.ulogovan = JSON.parse(ul)

    this.dostavaServis.dohvatiDostave().subscribe((dos : Dostava[])=>{
      if(dos){

        dos.forEach((d)=>{
          if(d.restoran == this.ulogovan.restoran && d.status == 0){
            this.dostave.push(d)
          }
        })

        this.dostave.forEach((d)=>{
          this.checkedOdbij.push(false)
          this.checkedPrihvati.push(false)
          this.procenjenoVreme.push("")
        })

      }
    })

  }

  potvrdi(){

    for(let i = 0; i < this.checkedPrihvati.length; i ++){
      if(this.checkedPrihvati[i] == true){
        this.dostave[i].ocekivanoVreme = this.procenjenoVreme[i]
        this.dostave[i].status = 1
        this.dostavaServis.azuriraj(this.dostave[i]).subscribe((msg: Message)=>{
          if(msg){

          }
        })
      }
      else if(this.checkedOdbij[i] == true){
        this.dostave[i].status = 2
        this.dostavaServis.azuriraj(this.dostave[i]).subscribe((msg: Message)=>{
          if(msg){

          }
        })
      }
    }

    alert("Uspešno ažuriranje!")
    window.location.reload()

  }

}
