import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KonobardostaveComponent } from './konobardostave.component';

describe('KonobardostaveComponent', () => {
  let component: KonobardostaveComponent;
  let fixture: ComponentFixture<KonobardostaveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KonobardostaveComponent]
    });
    fixture = TestBed.createComponent(KonobardostaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
